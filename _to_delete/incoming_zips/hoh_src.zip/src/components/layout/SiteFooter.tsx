import Image from "next/image";
import Link from "next/link";
import {
  footerPagesColumn,
  footerQuickLinksColumn,
  footerContact,
  footerDisclaimer,
  footerRera,
  footerBrandBlurb,
  footerBuilderBlurb,
} from "@/data/navigation";

export function SiteFooter() {
  return (
    <footer className="bg-brand-dark text-brand-white">
      <div className="container-page grid gap-12 py-16 md:grid-cols-2 lg:grid-cols-4">
        <div className="space-y-4 lg:col-span-1">
          <Image
            src="/images/brand/header-logo.svg"
            alt="Heart of Harmony by CKPC Properties"
            width={180}
            height={40}
            className="h-8 w-auto"
          />
          <p className="text-sm text-brand-border">{footerBrandBlurb}</p>
          <div className="flex gap-3 pt-2">
            {["Instagram", "LinkedIn", "Facebook", "YouTube"].map((label) => (
              <span
                key={label}
                aria-label={label}
                className="flex h-8 w-8 items-center justify-center rounded-full border border-white/20 text-xs text-brand-white/70"
              >
                {label[0]}
              </span>
            ))}
          </div>
        </div>

        <div className="space-y-4 lg:col-span-1">
          <a href="https://www.ckpcproperties.com/" target="_blank" rel="noreferrer">
            <Image
              src="/images/brand/ckpc-logo.png"
              alt="CKPC Properties — builder of Heart of Harmony, Bengaluru"
              width={160}
              height={50}
              className="h-10 w-auto"
            />
          </a>
          <p className="text-sm text-brand-border">{footerBuilderBlurb}</p>
        </div>

        <div>
          <p className="mb-4 font-serif text-sm uppercase tracking-wide text-brand-white/80">
            Pages
          </p>
          <ul className="space-y-2.5 text-sm text-brand-border">
            {footerPagesColumn.map((l) => (
              <li key={l.href}>
                <Link href={l.href} className="hover:text-brand-white">
                  {l.label}
                </Link>
              </li>
            ))}
          </ul>

          <p className="mb-4 mt-8 font-serif text-sm uppercase tracking-wide text-brand-white/80">
            Quick links
          </p>
          <ul className="space-y-2.5 text-sm text-brand-border">
            {footerQuickLinksColumn.map((l) => (
              <li key={l.href}>
                <Link href={l.href} className="hover:text-brand-white">
                  {l.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <p className="mb-4 font-serif text-sm uppercase tracking-wide text-brand-white/80">
            Contact us
          </p>
          <ul className="space-y-2.5 text-sm text-brand-border">
            <li>
              <a href={footerContact.phoneHref} className="hover:text-brand-white">
                {footerContact.phone}
              </a>
            </li>
            <li>
              <a href={`mailto:${footerContact.email}`} className="hover:text-brand-white">
                {footerContact.email}
              </a>
            </li>
            <li>{footerContact.address}</li>
          </ul>

          <p className="mb-2 mt-8 font-serif text-sm uppercase tracking-wide text-brand-white/80">
            Disclaimer
          </p>
          <p className="text-xs leading-relaxed text-brand-border">{footerDisclaimer}</p>

          <p className="mb-2 mt-8 font-serif text-sm uppercase tracking-wide text-brand-white/80">
            RERA
          </p>
          <a
            href={footerRera.href}
            target="_blank"
            rel="noreferrer"
            className="text-xs text-brand-border hover:text-brand-white"
          >
            {footerRera.number}
          </a>
        </div>
      </div>

      <div className="border-t border-white/10 py-6">
        <p className="container-page text-center text-xs text-brand-border">
          © {new Date().getFullYear()} CKPC Heart of Harmony. All rights reserved.
        </p>
      </div>
    </footer>
  );
}
