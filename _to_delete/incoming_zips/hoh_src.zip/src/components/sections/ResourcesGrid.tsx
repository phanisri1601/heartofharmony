"use client";

import Image from "next/image";
import Link from "next/link";
import { useState } from "react";
import { motion } from "framer-motion";
import { articles } from "@/data/resources";

const PER_PAGE = 6;

export function ResourcesGrid() {
  const [page, setPage] = useState(1);
  const totalPages = Math.ceil(articles.length / PER_PAGE);
  const shown = articles.slice((page - 1) * PER_PAGE, page * PER_PAGE);

  return (
    <section className="bg-brand-offwhite py-16 md:py-24">
      <div className="container-page">
        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {shown.map((a, i) => (
            <motion.div
              key={a.href}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.5, delay: (i % 3) * 0.08 }}
            >
              <Link href={a.href} className="group block">
                <div className="relative aspect-[4/3] overflow-hidden rounded-xl">
                  <Image
                    src={a.image}
                    alt={a.title}
                    fill
                    sizes="(min-width: 1024px) 33vw, (min-width: 640px) 50vw, 100vw"
                    className="object-cover transition duration-500 group-hover:scale-105"
                  />
                </div>
                <h3 className="mt-4 font-serif text-base leading-snug text-brand-dark group-hover:text-brand-primary">
                  {a.title}
                </h3>
                <span className="mt-2 inline-block text-sm text-brand-primary">Read more →</span>
              </Link>
            </motion.div>
          ))}
        </div>

        {totalPages > 1 && (
          <div className="mt-12 flex items-center justify-center gap-2">
            {Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => (
              <button
                key={p}
                onClick={() => setPage(p)}
                aria-current={page === p ? "page" : undefined}
                className={`flex h-9 w-9 items-center justify-center rounded-full text-sm font-medium transition ${
                  page === p
                    ? "bg-brand-primary text-brand-white"
                    : "border border-brand-border text-brand-dark hover:border-brand-primary/40"
                }`}
              >
                {p}
              </button>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
