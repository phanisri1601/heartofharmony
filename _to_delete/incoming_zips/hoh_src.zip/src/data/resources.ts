// The 9 articles listed on /resources/ — extracted from the live archive page.

export const resourcesHero = {
  h1: "Heart of Harmony Blog — Real Estate, Location & Lifestyle Insights",
  intro:
    "The Heart of Harmony blog covers residential real estate in Bengaluru — from the Kudlu Gate and Hosur Road location story, to apartment design, lifestyle amenities, and the CKPC Properties builder track record.",
};

export const articles = [
  {
    title: "CKPC Properties Track Record — 8 Million Sq Ft, Fortune 100 Clients, Now Building Heart of Harmony",
    href: "/built-for-the-long-term-ckpcs-track-record-in-commercial-and-residential-spaces/",
    image: "/images/content/built-for-the-long-term-ckpcs-track-record-in-commercial-and-residential-spaces.jpg",
  },
  {
    title: "CKPC Properties New Launch on Hosur Road: Heart of Harmony at Kudlu Gate, Bengaluru",
    href: "/ckpc-properties-new-launch-hosur-road-heart-of-harmony/",
    image: "/images/content/ckpc-properties-new-launch-hosur-road-heart-of-harmony.jpg",
  },
  {
    title: "CKPC Properties Secures Long-Term TCS Office Lease — A Landmark for Grade A+ Commercial Real Estate",
    href: "/ckpc-secures-long-term-tcs-office-lease/",
    image: "/images/content/ckpc-secures-long-term-tcs-office-lease.png",
  },
  {
    title: "Heart of Harmony Amenities: Complete Guide to 40+ Facilities at Kudlu Gate, Bengaluru",
    href: "/exclusive-look-clubhouses-and-recreational-amenities-at-heart-of-harmony/",
    image: "/images/content/exclusive-look-clubhouses-and-recreational-amenities-at-heart-of-harmony.jpg",
  },
  {
    title: "Private Sky Garden Terraces at Heart of Harmony — 10 Ways to Make the Most of Your Outdoor Space",
    href: "/private-gardens-on-every-three-floors-10-things-you-can-do-in-your-private-gardens/",
    image: "/images/content/private-gardens-on-every-three-floors-10-things-you-can-do-in-your-private-gardens.jpg",
  },
  {
    title: "Heart of Harmony Floor Plans: Smart 3 BHK, 3.5 BHK & 4 BHK Home Layouts Designed for Real Life",
    href: "/smart-layouts-at-heart-of-harmony-designed-for-the-way-you-live/",
    image: "/images/content/smart-layouts-at-heart-of-harmony-designed-for-the-way-you-live.jpg",
  },
  {
    title: "The Thinking Behind (PX): Designing Spaces Around People Experience",
    href: "/the-thinking-behind-px-designing-spaces-around-people-experience/",
    image: "/images/content/the-thinking-behind-px-designing-spaces-around-people-experience.jpg",
  },
  {
    title: "Heart of Harmony on Hosur Road: How Highway, Metro and Lifestyle Access Work Together",
    href: "/what-is-the-triad-of-delight-location-that-works-on-every-front/",
    image: "/images/content/what-is-the-triad-of-delight-location-that-works-on-every-front.jpg",
  },
  {
    title: "Why Kudlu Gate is Bengaluru's Next Residential Growth Corridor",
    href: "/why-kudlu-gate-is-bengalurus-next-residential-growth-corridor/",
    image: "/images/content/why-kudlu-gate-is-bengalurus-next-residential-growth-corridor.png",
  },
];
