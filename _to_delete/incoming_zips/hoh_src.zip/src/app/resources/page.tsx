import type { Metadata } from "next";
import { ContentHero } from "@/components/content/ContentHero";
import { ResourcesGrid } from "@/components/sections/ResourcesGrid";
import { ContactSection } from "@/components/sections/ContactSection";
import { resourcesHero } from "@/data/resources";

export const metadata: Metadata = {
  title: "Blog — Real Estate Insights, Location & Lifestyle",
  description:
    "Read insights on Kudlu Gate real estate, Heart of Harmony amenities, Hosur Road lifestyle, and CKPC builder updates.",
  alternates: { canonical: "/resources/" },
  openGraph: {
    title: "Heart of Harmony Blog — Real Estate Insights, Location & Lifestyle | CKPC",
    description:
      "Read insights on Kudlu Gate real estate, Heart of Harmony amenities, Hosur Road lifestyle, and CKPC builder updates.",
    url: "/resources/",
    type: "website",
  },
};

export default function ResourcesPage() {
  return (
    <>
      <ContentHero eyebrow="Resources" title={resourcesHero.h1} intro={resourcesHero.intro} />
      <ResourcesGrid />
      <ContactSection />
    </>
  );
}
